<?php 


if(empty(false)){
    echo "true";
}else{
    echo "false";
}
?>